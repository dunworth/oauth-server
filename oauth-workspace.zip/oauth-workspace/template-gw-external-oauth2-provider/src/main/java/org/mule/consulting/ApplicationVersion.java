package org.mule.consulting;

import org.mule.api.MuleException;
import org.mule.api.agent.Agent;
import org.mule.api.lifecycle.InitialisationException;

public class ApplicationVersion implements Agent {
	private String description = "?.?";
	String name = "Unknown";

	@Override
	public void initialise() throws InitialisationException {
	}

	@Override
	public void start() throws MuleException {
	}

	@Override
	public void stop() throws MuleException {
	}

	@Override
	public void dispose() {
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public String getDescription() {
		return "Source Version: " + name + " v" + description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
}
